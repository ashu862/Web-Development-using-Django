from django.contrib import admin
from . models import Jobs, Resume

# Register your models here.
admin.site.register(Jobs)
admin.site.register(Resume)