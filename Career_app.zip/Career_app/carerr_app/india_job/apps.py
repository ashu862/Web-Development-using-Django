from django.apps import AppConfig


class IndiaJobConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'india_job'
